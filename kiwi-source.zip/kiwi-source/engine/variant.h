#ifndef __VARIANT_H__
#define __VARIANT_H__

#include "buffer.h"

typedef enum {ADD,DEL} OPT;
typedef Buffer Variant;

#endif
