#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdint.h>
#include <string.h>
#include <time.h>
#include <sys/time.h>
#include "../engine/db.h"


#define KSIZE (16)
#define VSIZE (1000)

#define LINE "+-----------------------------+----------------+------------------------------+-------------------+\n"
#define LINE1 "---------------------------------------------------------------------------------------------------\n"

typedef struct data{
	long int count;
	int r;
	int nhmata;
	DB* db;
	int found;
}Data;

pthread_mutex_t timeLock;

long long get_ustime_sec(void);
void _random_key(char *key,int length);
