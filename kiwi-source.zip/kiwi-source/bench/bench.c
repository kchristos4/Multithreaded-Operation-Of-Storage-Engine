#include "bench.h"

void _random_key(char *key,int length) {
	int i;
	char salt[36]= "abcdefghijklmnopqrstuvwxyz0123456789";

	for (i = 0; i < length; i++)
		key[i] = salt[rand() % 36];
}

void _print_header(int count)
{
	double index_size = (double)((double)(KSIZE + 8 + 1) * count) / 1048576.0;
	double data_size = (double)((double)(VSIZE + 4) * count) / 1048576.0;

	printf("Keys:\t\t%d bytes each\n", 
			KSIZE);
	printf("Values: \t%d bytes each\n", 
			VSIZE);
	printf("Entries:\t%d\n", 
			count);
	printf("IndexSize:\t%.1f MB (estimated)\n",
			index_size);
	printf("DataSize:\t%.1f MB (estimated)\n",
			data_size);

	printf(LINE1);
}

void _print_environment()
{
	time_t now = time(NULL);

	printf("Date:\t\t%s", 
			(char*)ctime(&now));

	int num_cpus = 0;
	char cpu_type[256] = {0};
	char cache_size[256] = {0};

	FILE* cpuinfo = fopen("/proc/cpuinfo", "r");
	if (cpuinfo) {
		char line[1024] = {0};
		while (fgets(line, sizeof(line), cpuinfo) != NULL) {
			const char* sep = strchr(line, ':');
			if (sep == NULL || strlen(sep) < 10)
				continue;

			char key[1024] = {0};
			char val[1024] = {0};
			strncpy(key, line, sep-1-line);
			strncpy(val, sep+1, strlen(sep)-1);
			if (strcmp("model name", key) == 0) {
				num_cpus++;
				strcpy(cpu_type, val);
			}
			else if (strcmp("cache size", key) == 0)
				strncpy(cache_size, val + 1, strlen(val) - 1);	
		}

		fclose(cpuinfo);
		printf("CPU:\t\t%d * %s", 
				num_cpus, 
				cpu_type);

		printf("CPUCache:\t%s\n", 
				cache_size);
	}
}

int main(int argc,char** argv)
{
	long int count;
	int nhmata;					//enas int pou apothikevei ton arithmo twn nhmatwn apo ton xristi
	int percentage;				//enas int pou apothikevei to % twn read pou dinetai apo ton xristi

	srand(time(NULL));
	if (argc < 3) {
		fprintf(stderr,"Usage: db-bench <write | read | readwrite> <count> <thread number>\n");  //added readwrite
		exit(1);
	}
	
	if (strcmp(argv[1], "write") == 0) {
		int r = 0;

		count = atoi(argv[2]);
		_print_header(count);
		_print_environment();
		if (argc == 4)
			r = 1;
		_write_test(count, r);
	} else if (strcmp(argv[1], "read") == 0) {
		int r = 0;

		count = atoi(argv[2]);
		_print_header(count);
		_print_environment();
		if (argc == 4)
			r = 1;
		
		_read_test(count, r);
	} else if (strcmp(argv[1], "readwrite") == 0) {      //an dwthei readwrite ws orisma mpainei edw
		int r = 0; 										 //arxikopoiisi tou r (an r=1 exoume random values sta read / write)

		count = atoi(argv[2]);							 //metatrepei to 3o orisma se int gia na aksiopoiithei stin ylopoiisi
		_print_header(count);							 //oi 2 print xrisimopoiountai gia na moiazei i readwrite me tis read kai write se emfanisi sto termatiko
		_print_environment();
		
		if (argc == 4){ 
			r = 0;
			nhmata = atoi(argv[3]);						 //metatrepei to 4o orisma se int
		}
		if (argc == 5){
			r=0;
			nhmata = atoi(argv[3]);						 //metatrepei to 4o orisma se int ->nhmata
			percentage = atoi(argv[4]);					 //kai to 5o se int ->percentage
		}

		_readwrite_test(count, r, nhmata, percentage);			//kalei tin readwrite
	} else {
		fprintf(stderr,"Usage: db-bench <write | read | readwrite> <count> \n");  //added readwrite 
		exit(1);
	}

	return 1;
}
