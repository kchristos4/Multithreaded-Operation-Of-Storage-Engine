#include <string.h>
#include "../engine/db.h"
#include "../engine/variant.h"
#include "bench.h"
#include <pthread.h>
#include <math.h> // tin xreiazomaste gia tin floor()

#define DATAS ("testdb")
double Time_previous , Total_cost;	//Time_previous : global metablhth pou isoutai me thn xroniki stigmi pou teleiwse to teleftaio nhma

void _write_test(long int count, int r)
{
	int i;
	double cost;
	long long start,end;
	Variant sk, sv;
	DB* db;

	char key[KSIZE + 1];
	char val[VSIZE + 1];
	char sbuf[1024];

	memset(key, 0, KSIZE + 1);
	memset(val, 0, VSIZE + 1);
	memset(sbuf, 0, 1024);

	db = db_open(DATAS);

	start = get_ustime_sec();
	for (i = 0; i < count; i++) {
		if (r)
			_random_key(key, KSIZE);
		else										//epeidh r=0 mpainei sto else
			snprintf(key, KSIZE, "key-%d", i);	
		fprintf(stderr, "%d adding %s\n", i, key);
		snprintf(val, VSIZE, "val-%d", i);

		sk.length = KSIZE;							//arxikopoiei tis times tou key kai ths value ta opoia einai struct Variant(=buffer.h) 
		sk.mem = key;
		sv.length = VSIZE;
		sv.mem = val;

		db_add(db, &sk, &sv);						//pros8etei kleidi-timh sto database(=db)
		if ((i % 10000) == 0) {
			fprintf(stderr,"random write finished %d ops%30s\r", 
					i, 
					"");

			fflush(stderr);                          //oti teleiwse 10000 operation   
		}
	}

	db_close(db);							//kleinei database

	end = get_ustime_sec();
	cost = end -start;						//ypologizei to kostos(se xrono) pou xreiasthke gia na ginei auth h energeia 

	printf(LINE);
	printf("|Random-Write	(done:%ld): %.6f sec/op; %.1f writes/sec(estimated); cost:%.3f(sec);\n"
		,count, (double)(cost / count)
		,(double)(count / cost)
		,cost);								//edw tuponontai statistika sto telos tou programmatos
}

void _read_test(long int count, int r)
{
	int i;
	int ret;
	int found = 0;
	double cost;
	long long start,end;
	Variant sk;
	Variant sv;
	DB* db;
	char key[KSIZE + 1];

	db = db_open(DATAS);
	start = get_ustime_sec();
	for (i = 0; i < count; i++) {
		memset(key, 0, KSIZE + 1);

		/* if you want to test random write, use the following */
		if (r)
			_random_key(key, KSIZE);
		else
			snprintf(key, KSIZE, "key-%d", i);			//epeidh r=1 mpainei sto else
		fprintf(stderr, "%d searching %s\n", i, key);
		sk.length = KSIZE;
		sk.mem = key;
		ret = db_get(db, &sk, &sv);
		if (ret) {									// ret = 1 shmainei oti brethhke auto pou psaxname
			//db_free_data(sv.mem);					//otan vriskoume ena kleidi an theloume na to bgazoume apo to database
			found++;
		} else {
			INFO("not found key#%s", 
					sk.mem);
    	}

		if ((i % 10000) == 0) {
			fprintf(stderr,"random read finished %d ops%30s\r", 
					i, 
					"");

			fflush(stderr);
		}
	}

	db_close(db);						//kleinei database
	end = get_ustime_sec();
	cost = end - start;					//ypologizei to kostos(se xrono) pou xreiasthke gia na ginei auth h enrgeia
	printf(LINE);
	printf("|Random-Read	(done:%ld, found:%d): %.6f sec/op; %.1f reads /sec(estimated); cost:%.3f(sec)\n",
		count, found,
		(double)(cost / count),
		(double)(count / cost),
		cost);						//edw tuponontai statistika sto telos tou programmatos
}

void* _read_test1(void * arg)					/* pairnei ws orismata ta args*/
{
	Data *d = (Data *) arg;						/* xrisimopoiountai oles oi metavlites pou xrisimopoiountan kai stin original _write_test() */
	int i;
	int ret;
	double cost;
	long long start,end;
	Variant sk_r;
	Variant sv_r;
	char key_r[KSIZE + 1];

	pthread_mutex_init(&timeLock, NULL);		/* kanoume initialize to timeLock pou orisame sto bench.h*/
	pthread_mutex_lock(&timeLock);				/* kanoume lock to mutex timeLock prokeimenou na kratisei ta statistika tou xronou */
	printf(LINE);								/* pou tha apothikefsoume se ligo xwris na ta epireasoun ta alla nimata*/
	printf("Entering function _read_test1() with <%ld> (thread id)\n", pthread_self());
	start = get_ustime_sec();					/* ta start/end/cost einai i metavlites gia ton xrono pou ipirxan idi*/


	for (i = 0; i < d->count; i++) {
		memset(key_r, 0, KSIZE + 1);

		/* if you want to test random write, use the following */
		if (d->r)
			_random_key(key_r, KSIZE);	
		else
			snprintf(key_r, KSIZE, "key-%d", i);			
		fprintf(stderr, "%d searching %s\n", i, key_r);
		sk_r.length = KSIZE;										/*OLI I FOR EINAI IDIA ME TIN FOR TIS ARXIKIS write_test() ME EKSAIRESI TA DEDOMENA POU ERXONTAI APO TA ARGS */
		sk_r.mem = key_r;											/*TIS SYNARTISIS TA OPOIA ALLAKSANE (px. i metavliti 'db' egine 'd->db' , 'found' egine 'd->found' ) */
		ret = db_get(d->db, &sk_r, &sv_r);
		if (ret) {									// ret = 1 shmainei oti brethhke auto pou psaxname
			//db_free_data(sv_r.mem);
			d->found ++;
		} else {
			INFO("not found key#%s", 
					sk_r.mem);
    	}

		if ((i % 10000) == 0) {
			fprintf(stderr,"random read finished %d ops%30s\r", 
					i, 
					"");

			fflush(stderr);
		}
	}

	end = get_ustime_sec();
	cost = end - start;									//ypologizei to topiko kostos(se xrono) pou xreiasthke gia na ginei auth h energeia 

	Total_cost = Total_cost + (get_ustime_sec()-Time_previous);									/* prosthetei sto total_cost tin sigkekrimeni xroniki stigmi 'meion'             */
	printf("This thread took another %.3fseconds to end\n", get_ustime_sec()-Time_previous);	/* tin xroniki stigmi pou termatise to proigoumeno nima (an einai to 1o nima     */
	Time_previous = get_ustime_sec();															/* tote i previous exei tin timi stin opoia arxikopoiithike stin readwrite_test  */
																								/* epeita allazoume ws tin xroniki stigmi pou teleiwse to teleftaio nima to paron*/	
	
	printf(LINE);
	printf("|Random-Read	(done:%ld, found:%d): %.6f sec/op; %.1f reads /sec(estimated); cost:%.3f(sec)\n",
		d->count, d->found,
		(double)(cost / d->count),
		(double)(d->count / cost),
		cost);																			//edw tuponontai epimerous statistika tou nimatos

	pthread_mutex_unlock(&timeLock);													//edw tuponontai epimerous statistika tou nimatos
	pthread_mutex_destroy(&timeLock);													/* unlock to timeLock gia na mporei na allaksei tin timi twn total cost kai  */
																						/* time_previous ena allo nima kai meta deallocate to time lock*/
	return 0;
}

void *_write_test1(void *arg)			/* pairnei ws orismata ta args*/
{
	Data *d = (Data *) arg;				/* xrisimopoiountai oles oi metavlites pou xrisimopoiountan kai stin original _write_test() */
	int i;
	double cost;
	long long start,end;
	Variant sk_w, sv_w;

	char key_w[KSIZE + 1];
	char val[VSIZE + 1];
	char sbuf[1024];

	memset(key_w, 0, KSIZE + 1);
	memset(val, 0, VSIZE + 1);
	memset(sbuf, 0, 1024);

	pthread_mutex_init(&timeLock, NULL);						/* kanoume initialize to timeLock pou orisame sto bench.h*/
	pthread_mutex_lock(&timeLock);								/* kanoume lock to mutex timeLock prokeimenou na kratisei ta statistika tou xronou */
	printf(LINE);												/* pou tha apothikefsoume se ligo xwris na ta epireasoun ta alla nimata*/
	printf("Entering function _write_test1() with <%ld> (thread id)\n", pthread_self());
	start = get_ustime_sec();									/* ta start/end/cost einai i metavlites gia ton xrono pou ipirxan idi*/

	
	for (i = 0; i < d->count; i++) {
		if (d->r)
			_random_key(key_w, KSIZE);
		else													
			snprintf(key_w, KSIZE, "key-%d", i);	
		fprintf(stderr, "%d adding %s\n", i, key_w);
		snprintf(val, VSIZE, "val-%d", i);

		sk_w.length = KSIZE;									//arxikopoiei tis times tou key kai ths value ta opoia einai struct Variant(=buffer.h) 
		sk_w.mem = key_w;
		sv_w.length = VSIZE;									/*OLI I FOR EINAI IDIA ME TIN FOR TIS ARXIKIS write_test() ME EKSAIRESI TA DEDOMENA POU ERXONTAI APO TA ARGS */
		sv_w.mem = val;											/*TIS SYNARTISIS TA OPOIA ALLAKSANE (px. i metavliti 'db' egine 'd->db' ) */

		db_add(d->db, &sk_w, &sv_w);							//pros8etei kleidi-timh sto database(=db)
		if ((i % 10000) == 0) {
			fprintf(stderr,"random write finished %d ops%30s\r", 
					i, 
					"");

			fflush(stderr);                          			//oti teleiwse 10000 operation   
		}
	}


	end = get_ustime_sec();
	cost = end - start;											//ypologizei to topiko kostos(se xrono) pou xreiasthke gia na ginei auth h energeia 

	Total_cost = Total_cost + (get_ustime_sec()-Time_previous);									/* prosthetei sto total_cost tin sigkekrimeni xroniki stigmi 'meion'             */
	printf("This thread took another %.6f seconds to end\n", get_ustime_sec()-Time_previous);	/* tin xroniki stigmi pou termatise to proigoumeno nima (an einai to 1o nima     */
	Time_previous = get_ustime_sec();															/* tote i previous exei tin timi stin opoia arxikopoiithike stin readwrite_test  */
																								/* epeita allazoume ws tin xroniki stigmi pou teleiwse to teleftaio nima to paron*/	
	
	printf(LINE);
	printf("|Random-Write	(done:%ld): %.6f sec/op; %.1f writes/sec(estimated); cost:%.3f(sec);\n"
		,d->count, (double)(cost / d->count)
		,(double)(d->count / cost)
		,cost);																						//edw tuponontai epimerous statistika tou nimatos
	pthread_mutex_unlock(&timeLock);																/* unlock to timeLock gia na mporei na allaksei tin timi twn total cost kai  */
	pthread_mutex_destroy(&timeLock);																/* time_previous ena allo nima kai meta deallocate to time lock*/

	return 0;								
}

void _readwrite_test(long int count, int r, int nhmata , int percentage)
{
	pthread_t tid[nhmata];															//dilwseis nhmatwn analogws me to posa zitisei o xristis
	pthread_t threadid[2];															//2 epipleon threads ta opoia tha eksigisoume parakatw
	Data thread_args;																//dilwsi mias metavlitis me to onoma "thread_args" typou Data (pou einai ena struct stin bench.h)
	int i;																			//dilwsi metavlitis gia na tin xrisimopoiisoume stis for(;;)
	if (nhmata>count){																//an ta nhmata einai perissotera apo ta counts prokalei segmentation fault
		nhmata = count;																//opote valame na ginontai tosa nhmata oses kai oi prakseis pou xreiazontai
	}																				//px. 10 ops kai 100 nhmata => 10 nhmata pou tha kanoun apo 1 op (kai ta alla 90 den tha dimiourgithoun kan)

	thread_args.count = count/nhmata;												//arxikopoiisi twn pediwn tou thread_args
	thread_args.r = r;
	thread_args.nhmata = nhmata;
	thread_args.db = db_open(DATAS);									
	thread_args.found = 0;															//i thread_args.found den aksiopoieitai apo tis write wstoso einai aparaititi gia tis read

	Time_previous  = get_ustime_sec();												//time_previous pairnei ws timi tin enarksi tis readwrite_test											
	if(nhmata == 1){
		pthread_create(&tid[0], NULL, _write_test1, (void *) &thread_args);			/* dimourgeitai 1 nhma kai ektelei tin write_test1*/
		pthread_detach(tid[0]);														/* apodesmevetai to nhma me tin detach*/
		db_close(thread_args.db);													/* kleinei to db*/
		printf("_write_test1() finished...\n");										/* 2 print gia na kseroume oti teleiwse to 1 kai ksekinise to allo*/

		printf("Preparing for _read_test1()...\n");
		thread_args.db = db_open(DATAS);											/* anoigei to db*/
		pthread_create(&tid[0], NULL, _read_test1, (void *) &thread_args);			/* kaleitai i read_test me to idio thread*/
		pthread_join(tid[0], NULL);													/* ginetai join to nhma*/
	}else{
		for(i = 0; i < nhmata; i ++){													/* Mexri o i na ftasei stin timi tou nhmata (ta opoia exoun dwthei ws input apo ton xristi) ektelese tin */
			if (i%2 == 0){ 																/* Pthread create enallaks mia gia na kalesei tin read_test1 kai mia gia na kalesei tin write_test1      */
				pthread_create(&tid[i], NULL, _write_test1, (void *) &thread_args);		/* i enallagi epitigxanetai me to na checkaroume an to ypoloipo tis diairesis tou i me to 2 einai == 0   */
			}																			/* dld an o i einai artios ektaileitai i write_test1 enw perittos i read_test1                           */
			else {																		
				pthread_create(&tid[i], NULL, _read_test1, (void *) &thread_args);		
			}																			
		}


		for(i = 0; i < nhmata; i ++){													/* kanoume join ta nhmata pou kaname create parapanw */
			pthread_join(tid[i], NULL);
		}


		if(count != thread_args.count*nhmata){																						/* elegxoume an to count pou dwthike (diladi ta operations )*/
																																	/* einai iso me to posa nhmata anatethikan     */
			printf("\n Effort to put/get the operations that were lost in the division of count/nhmata (when nhmata is odd)\n");	/* se kathe thread epi to posa threads dimiourgithikan  */
			thread_args.count = (count - thread_args.count*nhmata) / 2;																/* kai an den einai isa tote afti i if epixeirei */
			printf("\n Operations that were lost  = %ld\n", 2*thread_args.count);													/* na ektelesei ta operations pou den ektelestikan */
			for (i=0; i<2;i++){																										/* px. 100ops 3 threads 33ops per thread 33*3 = 99 != 100*/
				if (i%2 == 0){																										/* ara prospathei na kanei tin 1 xameni praksi*/
					pthread_create(&threadid[i], NULL, _write_test1, (void *) &thread_args);										/* edw xrisimopoiountai ta 2 parapanw threads */
																																	/*	pou dimiourgisame stin grammi 262 1 thread read kai 1 write*/																	
				}
				else{
					pthread_create(&threadid[i], NULL, _read_test1, (void *) &thread_args);	
				}
			}
			
			
			for(i = 0; i < 2; i ++){
			pthread_join(threadid[i], NULL);																						/* join ta 2 threads */
			}
			
			
		}

		
		
	}
	db_close(thread_args.db);																										/*kleinoume to db*/
	printf(LINE1);																													/* print grammi gia na ta diaxwrizoume*/
	printf("|Random-Read/Write	(done:%ld, found:%d): %.6f sec/op; %.1f reads/writes /sec(estimated); Total cost:%.3f(sec) with %d threads\n",	
		count, thread_args.found,
		(double)(Total_cost / count),																								/*print final stats*/
		(double)(count / Total_cost),
		Total_cost, nhmata);
	
}


